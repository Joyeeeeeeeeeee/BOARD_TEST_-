# SPRING_BOARD_TEST
SPRING_BOARD_TEST 평가

1. GIT CLONE
https://github.com/ALOHA-CLASS/SPRING_BOARD_TEST.git

2. 준비 파일을 사용한다.

3. 준비 파일의 BoardApplicationTests.java 테스트 코드로 검증한다.

4. 완성한 board 프로젝트를 GITHUB 에 올리고 제출한다. 
